from collections import deque
from .dijkstras import haversine

def bfs(source, destination, places):
    """Find a path using Breadth-First Search"""
    if source not in places or destination not in places:
        return []
        
    # Initialize queue with source node
    queue = deque([(source, [source])])
    visited = set([source])
    
    while queue:
        current, path = queue.popleft()
        
        # If we've reached the destination, return the path
        if current == destination:
            return path
            
        # Explore all neighbors
        for neighbor in places:
            if neighbor != current and neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))
    
    return []  # No path found
