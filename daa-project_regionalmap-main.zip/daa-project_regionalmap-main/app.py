from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import csv
import random
from algorithms.bfs import bfs
from algorithms.dfs import dfs
from algorithms.dijkstras import dijkstra
from algorithms.dijkstras import haversine
import os
from datetime import datetime, timedelta
import requests
import json
import math

app = Flask(__name__, static_folder='.')
CORS(app)

# Load places
places = {}
with open('data/places.csv', 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        places[row['Name']] = (float(row['Latitude']), float(row['Longitude']))

# Traffic patterns for different times of day
def get_traffic_level():
    current_hour = datetime.now().hour
    # Morning rush hour (8-10 AM)
    if 8 <= current_hour < 10:
        return random.choices(['heavy', 'moderate', 'light'], weights=[0.6, 0.3, 0.1])[0]
    # Evening rush hour (5-7 PM)
    elif 17 <= current_hour < 19:
        return random.choices(['heavy', 'moderate', 'light'], weights=[0.7, 0.2, 0.1])[0]
    # Night time (10 PM - 5 AM)
    elif 22 <= current_hour or current_hour < 5:
        return random.choices(['heavy', 'moderate', 'light'], weights=[0.1, 0.2, 0.7])[0]
    # Day time
    else:
        return random.choices(['heavy', 'moderate', 'light'], weights=[0.2, 0.5, 0.3])[0]

# Warning types and their locations with accurate coordinates and messages
warning_areas = [
    # Accidents - Known accident-prone areas
    (30.7353, 79.0669, "⚠️ Accident: Landslide area near Kedarnath", "accident"),
    (30.7443, 79.4932, "⚠️ Accident: Sharp curve on Badrinath highway", "accident"),
    (30.5555, 79.5603, "⚠️ Accident: Vehicle skid near Joshimath", "accident"),
    (30.0869, 78.2676, "⚠️ Accident: Tourist bus collision in Rishikesh", "accident"),
    
    # Traffic - Known traffic congestion points
    (30.3165, 78.0322, "🚗 Heavy Traffic: Dehradun ISBT area", "traffic"),
    (29.9457, 78.1642, "🚗 Heavy Traffic: Haridwar bypass", "traffic"),
    (30.4598, 78.0648, "🚗 Heavy Traffic: Mussoorie Mall Road", "traffic"),
    (29.3919, 79.4542, "🚗 Heavy Traffic: Nainital Mallital", "traffic"),
    
    # Weather Warnings
    (30.3165, 78.0322, "🌧️ Weather: Heavy rain in Dehradun", "weather"),
    (30.4598, 78.0648, "🌫️ Weather: Dense fog in Mussoorie", "weather"),
    (30.7289, 78.4445, "❄️ Weather: Snowfall in Uttarkashi", "weather"),
    (30.4205, 79.3203, "🌧️ Weather: Heavy rain in Chamoli", "weather"),
    
    # Road Blocks
    (30.7289, 78.4445, "🚧 Road Block: Uttarkashi-Gangotri highway", "roadblock"),
    (30.4205, 79.3203, "🚧 Road Block: Chamoli-Gopeshwar road", "roadblock"),
    (30.1513, 78.7772, "🚧 Road Block: Pauri-Kotdwar highway", "roadblock"),
    (30.3833, 78.4803, "🚧 Road Block: Tehri dam area", "roadblock")
]

def get_warning_icon(warning_type):
    """Get appropriate icon for warning type"""
    icons = {
        "accident": "fa-exclamation-triangle",
        "traffic": "fa-car",
        "weather": "fa-cloud-rain",
        "roadblock": "fa-road"
    }
    return icons.get(warning_type, "fa-exclamation-circle")

def get_warning_color(warning_type):
    """Get appropriate color for warning type"""
    colors = {
        "accident": "#dc3545",  # Red
        "traffic": "#ffc107",   # Yellow
        "weather": "#17a2b8",   # Blue
        "roadblock": "#fd7e14"  # Orange
    }
    return colors.get(warning_type, "#6c757d")

def get_nearby_accidents(lat, lon, radius=50):
    """Get accidents within a certain radius of the given coordinates"""
    nearby_accidents = []
    for acc_lat, acc_lon, message in warning_areas:
        distance = haversine(lat, lon, acc_lat, acc_lon)
        if distance <= radius:
            # Add random severity and time
            severity = random.choice(["Low", "Medium", "High"])
            time_ago = random.randint(5, 120)  # minutes ago
            nearby_accidents.append({
                "location": [acc_lat, acc_lon],
                "message": f"{message} ({severity} severity, {time_ago} minutes ago)",
                "distance": round(distance, 1)
            })
    return nearby_accidents

def point_to_line_distance(point, line_start, line_end):
    """Calculate distance from point to line segment in kilometers"""
    lat, lon = point
    lat1, lon1 = line_start
    lat2, lon2 = line_end
    
    # Convert to radians
    lat = math.radians(lat)
    lon = math.radians(lon)
    lat1 = math.radians(lat1)
    lon1 = math.radians(lon1)
    lat2 = math.radians(lat2)
    lon2 = math.radians(lon2)
    
    # Calculate the cross-track distance
    d13 = haversine(math.degrees(lat1), math.degrees(lon1), 
                    math.degrees(lat), math.degrees(lon))
    bearing13 = math.atan2(
        math.sin(lon - lon1) * math.cos(lat),
        math.cos(lat1) * math.sin(lat) - 
        math.sin(lat1) * math.cos(lat) * math.cos(lon - lon1)
    )
    bearing12 = math.atan2(
        math.sin(lon2 - lon1) * math.cos(lat2),
        math.cos(lat1) * math.sin(lat2) - 
        math.sin(lat1) * math.cos(lat2) * math.cos(lon2 - lon1)
    )
    
    # Calculate the distance
    return abs(math.asin(math.sin(d13/6371) * 
              math.sin(bearing13-bearing12))) * 6371

def is_point_on_path(point, path_segment, max_distance=0.1):
    """Check if a point is on the path segment within max_distance (in km)"""
    start, end = path_segment
    distance = point_to_line_distance(point, start, end)
    
    if distance <= max_distance:
        # Calculate progress along the path
        total_dist = haversine(start[0], start[1], end[0], end[1])
        if total_dist == 0:
            return False, None
            
        # Check if point is between start and end
        dist_to_start = haversine(point[0], point[1], start[0], start[1])
        dist_to_end = haversine(point[0], point[1], end[0], end[1])
        
        if dist_to_start <= total_dist and dist_to_end <= total_dist:
            return True, dist_to_start
            
    return False, None

def get_osrm_route(start, end):
    """Get route from OSRM service"""
    base_url = "http://router.project-osrm.org/route/v1/driving/"
    coordinates = f"{start[1]},{start[0]};{end[1]},{end[0]}"
    url = f"{base_url}{coordinates}?overview=full&geometries=geojson"
    
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            if data['code'] == 'Ok':
                return data['routes'][0]['geometry']['coordinates']
        return None
    except Exception as e:
        print(f"Error getting OSRM route: {e}")
        return None

def get_route_details(mode, distance, terrain, traffic_level):
    """Calculate route details based on transportation mode"""
    # Base speeds in km/h for different modes
    speeds = {
        'car': {
            'normal': 60,
            'mountainous': 40,
            'heavy_traffic': 0.5,
            'moderate_traffic': 0.75
        },
        'bike': {
            'normal': 40,
            'mountainous': 30,
            'heavy_traffic': 0.6,
            'moderate_traffic': 0.8
        },
        'bus': {
            'normal': 50,
            'mountainous': 35,
            'heavy_traffic': 0.4,
            'moderate_traffic': 0.7
        }
    }

    # Get base speed based on terrain
    base_speed = speeds[mode]['mountainous' if terrain == 'Mountainous' else 'normal']
    
    # Adjust speed based on traffic
    if traffic_level == 'heavy':
        base_speed *= speeds[mode]['heavy_traffic']
    elif traffic_level == 'moderate':
        base_speed *= speeds[mode]['moderate_traffic']

    # Calculate time in minutes
    time_minutes = (distance / base_speed) * 60

    # Add buffer time for stops and breaks
    if mode == 'bus':
        time_minutes += distance * 0.5  # 30 seconds per km for bus stops
    elif mode == 'car':
        time_minutes += distance * 0.2  # 12 seconds per km for traffic signals

    # Convert to hours and minutes
    hours = int(time_minutes // 60)
    minutes = int(time_minutes % 60)

    return {
        'speed': round(base_speed, 1),
        'time_minutes': round(time_minutes),
        'time_hours': hours,
        'time_remaining_minutes': minutes,
        'stops': round(distance / 20) if mode == 'bus' else 0  # Bus stops every 20km
    }

@app.route('/')
def home():
    return send_from_directory('.', 'index.html')

@app.route('/style.css')
def serve_css():
    return send_from_directory('.', 'style.css')

@app.route('/find-path', methods=['POST'])
def find_path():
    data = request.json
    source = data.get('source')
    destination = data.get('destination')
    method = data.get('method', 'dijkstra')
    mode = data.get('mode', 'car')  # Default to car if not specified
    
    if not source or not destination or source not in places or destination not in places:
        return jsonify({'error': 'Invalid source or destination'}), 400
    
    # Get path based on selected method
    if method == 'dijkstra':
        path = dijkstra(source, destination, places)
    elif method == 'bfs':
        path = bfs(source, destination, places)
    elif method == 'dfs':
        path = dfs(source, destination, places)
    else:
        return jsonify({'error': 'Invalid pathfinding method'}), 400
    
    if not path:
        return jsonify({'error': 'No path found'}), 404
    
    # Get actual road routes between each pair of points using OSRM
    road_path = []
    for i in range(len(path) - 1):
        start = places[path[i]]
        end = places[path[i + 1]]
        route = get_osrm_route(start, end)
        if route:
            road_path.extend([[coord[1], coord[0]] for coord in route])
        else:
            road_path.extend([start, end])
    
    # Calculate total distance
    total_distance = 0
    for i in range(len(road_path) - 1):
        lat1, lon1 = road_path[i]
        lat2, lon2 = road_path[i + 1]
        total_distance += haversine(lat1, lon1, lat2, lon2)
    
    # Get traffic level
    traffic_level = get_traffic_level()
    
    # Get terrain type
    terrain = 'Mountainous' if any(city in ['Mussoorie', 'Nainital', 'Almora', 'Pithoragarh'] for city in path) else 'Normal'
    
    # Get route details for the selected mode
    route_details = get_route_details(mode, total_distance, terrain, traffic_level)
    
    # Get warnings that are actually on the path
    path_warnings = []
    for i in range(len(road_path) - 1):
        start = road_path[i]
        end = road_path[i + 1]
        
        for lat, lon, message, warning_type in warning_areas:
            is_on_segment, dist_on_segment = is_point_on_path(
                (lat, lon), 
                (start, end)
            )
            
            if is_on_segment:
                path_warnings.append({
                    "location": [lat, lon],
                    "message": message,
                    "type": warning_type,
                    "icon": get_warning_icon(warning_type),
                    "color": get_warning_color(warning_type),
                    "distance": round(dist_on_segment, 1)
                })
    
    # Sort warnings by distance along the path
    path_warnings.sort(key=lambda x: x['distance'])
    
    return jsonify({
        "path": road_path,
        "distance": round(total_distance, 2),
        "time_minutes": route_details['time_minutes'],
        "time_hours": route_details['time_hours'],
        "time_remaining_minutes": route_details['time_remaining_minutes'],
        "speed": route_details['speed'],
        "stops": route_details['stops'],
        "traffic": traffic_level,
        "terrain": terrain,
        "mode": mode,
        "warnings": path_warnings
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
